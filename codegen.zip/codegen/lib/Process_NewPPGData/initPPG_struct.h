/*
 * initPPG_struct.h
 *
 * Code generation for function 'initPPG_struct'
 *
 */

#ifndef __INITPPG_STRUCT_H__
#define __INITPPG_STRUCT_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "Process_NewPPGData_types.h"

/* Function Declarations */
extern struct0_T initPPG_struct(void);

#endif

/* End of code generation (initPPG_struct.h) */
