/*
 * filterloopBPF07_30_26Hz.h
 *
 * Code generation for function 'filterloopBPF07_30_26Hz'
 *
 */

#ifndef __FILTERLOOPBPF07_30_26HZ_H__
#define __FILTERLOOPBPF07_30_26HZ_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "Process_NewPPGData_types.h"

/* Function Declarations */
extern void filterloopBPF07_30_26Hz(float in, struct1_T *Filt_struct);

#endif

/* End of code generation (filterloopBPF07_30_26Hz.h) */
