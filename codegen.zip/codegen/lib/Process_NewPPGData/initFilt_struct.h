/*
 * initFilt_struct.h
 *
 * Code generation for function 'initFilt_struct'
 *
 */

#ifndef __INITFILT_STRUCT_H__
#define __INITFILT_STRUCT_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "Process_NewPPGData_types.h"

/* Function Declarations */
extern struct1_T initFilt_struct(void);

#endif

/* End of code generation (initFilt_struct.h) */
