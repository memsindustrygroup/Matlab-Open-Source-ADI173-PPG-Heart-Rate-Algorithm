/*
 * Process_NewPPGData_initialize.h
 *
 * Code generation for function 'Process_NewPPGData_initialize'
 *
 */

#ifndef __PROCESS_NEWPPGDATA_INITIALIZE_H__
#define __PROCESS_NEWPPGDATA_INITIALIZE_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "Process_NewPPGData_types.h"

/* Function Declarations */
extern void Process_NewPPGData_initialize(void);

#endif

/* End of code generation (Process_NewPPGData_initialize.h) */
