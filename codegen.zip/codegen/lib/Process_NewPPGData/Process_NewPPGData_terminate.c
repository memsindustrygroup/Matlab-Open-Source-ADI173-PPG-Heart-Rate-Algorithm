/*
 * Process_NewPPGData_terminate.c
 *
 * Code generation for function 'Process_NewPPGData_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "Process_NewPPGData.h"
#include "PulseRateFilter_Experimental.h"
#include "initFilt_struct.h"
#include "initPPG_struct.h"
#include "stillness_update_eff.h"
#include "Process_NewPPGData_terminate.h"

/* Function Definitions */
void Process_NewPPGData_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (Process_NewPPGData_terminate.c) */
