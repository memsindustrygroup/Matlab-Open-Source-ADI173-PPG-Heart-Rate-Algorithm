/*
 * PulseRateFilter.h
 *
 * Code generation for function 'PulseRateFilter'
 *
 */

#ifndef __PULSERATEFILTER_H__
#define __PULSERATEFILTER_H__

/* Include files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "Process_NewPPGData_types.h"

/* Function Declarations */
extern void PulseRateFilter(struct0_T *PPG_struct);

#endif

/* End of code generation (PulseRateFilter.h) */
